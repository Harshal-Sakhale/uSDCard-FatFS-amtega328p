SPI mode atmega328p uSD card interfacing example.

Arduino SPI mode

13 SCK 	PB5
12 MISO	PB4
11 MOSI	PB3
10 SS 	PB2


